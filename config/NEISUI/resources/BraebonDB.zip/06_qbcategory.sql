insert into qbuserdefinedfields (userdefinedfieldname, classname, classfieldname, deleted) values ('Patient FirstName', 'Patient', 'firstName', '0');
insert into qbuserdefinedfields (userdefinedfieldname, classname, classfieldname, deleted) values ('Patient LastName', 'Patient', 'lastName', '0');
insert into qbuserdefinedfields (userdefinedfieldname, classname, classfieldname, deleted) values ('Patient DOB', 'Patient', 'dateOfBirth', '0');
insert into qbuserdefinedfields (userdefinedfieldname, classname, classfieldname, deleted) values ('Study Date', 'Studiesprime01', 'studydate', '0');

insert into qbcategory (categoryname, deleted) values ('Basic', '0');
insert into qbcategorydetails (categoryid, userdefinedfieldid) values (1, 1);
insert into qbcategorydetails (categoryid, userdefinedfieldid) values (1, 2);
insert into qbcategorydetails (categoryid, userdefinedfieldid) values (1, 3);
insert into qbcategorydetails (categoryid, userdefinedfieldid) values (1, 4);
