use noliswispicdb;
update studiesprime01 s01 set s01.patientid =
  (
    select b.NOLISpatientId
    from patientimportbraebon b
    where b.BraebonPatientId = s01.patientId
  );

alter table studiesprime01  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime02  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime03  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime04  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime05  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime06  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime07  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime09  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime10  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime11  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime12  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime13  add foreign key ( PatientID )  references Patient( ID );
alter table studiesprime14  add foreign key ( PatientID )  references Patient( ID );
